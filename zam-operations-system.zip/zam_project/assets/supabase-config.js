// ============================================
// إعدادات الاتصال بـ Supabase - نظام زام للعمليات
// ملف مشترك يتم تحميله في كل الشاشات
// ============================================

const SUPABASE_URL = 'https://uuphgpncmiwyigtqhjmd.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV1cGhncG5jbWl3eWlndHFoam1kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ4MjIzMzEsImV4cCI6MjEwMDM5ODMzMX0.R0ACUbjGYk22VljDl7z8c_kW9Mk7P3MmenbmBXcqWH4';

const zamClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ============================================
// إدارة جلسة المستخدم المسجل دخوله (محلياً في المتصفح)
// ============================================
const ZamSession = {
    KEY: 'zam_session_profile',

    save(profile) {
        sessionStorage.setItem(this.KEY, JSON.stringify(profile));
    },

    get() {
        const raw = sessionStorage.getItem(this.KEY);
        return raw ? JSON.parse(raw) : null;
    },

    clear() {
        sessionStorage.removeItem(this.KEY);
    },

    // يستخدم في بداية كل شاشة داخلية للتأكد إن فيه مستخدم مسجل دخوله
    // وإلا يرجعه لصفحة الدخول
    requireAuth(loginPath = '../index.html') {
        const profile = this.get();
        if (!profile) {
            window.location.href = loginPath;
            return null;
        }
        return profile;
    }
};

// ============================================
// دوال مساعدة عامة تستخدم في أكثر من شاشة
// ============================================
const ZamAPI = {
    // تسجيل الدخول برمز المرور
    async login(passcode) {
        const { data, error } = await zamClient
            .from('profiles')
            .select('*, branches(name)')
            .eq('passcode', passcode)
            .eq('status', 'active')
            .maybeSingle();

        if (error) throw error;
        return data; // null لو مفيش تطابق
    },

    // تسجيل موظف جديد (حالته الافتراضية pending لحد ما الإدارة توافق)
    async registerEmployee(payload) {
        const { data, error } = await zamClient
            .from('profiles')
            .insert([{ ...payload, status: 'pending' }])
            .select()
            .single();
        if (error) throw error;
        return data;
    },

    // جلب كل الفروع
    async getBranches() {
        const { data, error } = await zamClient.from('branches').select('*').order('name');
        if (error) throw error;
        return data;
    },

    // جلب موظفي فرع معين
    async getStaff(branchId = null) {
        let query = zamClient.from('profiles').select('*, branches(name)');
        if (branchId) query = query.eq('branch_id', branchId);
        const { data, error } = await query.order('full_name');
        if (error) throw error;
        return data;
    },

    // جلب قوائم التحقق (checklists) ليوم/فرع معين
    async getChecklists(branchId = null) {
        let query = zamClient.from('checklists').select('*, profiles(full_name)');
        if (branchId) query = query.eq('branch_id', branchId);
        const { data, error } = await query.order('created_at', { ascending: false });
        if (error) throw error;
        return data;
    },

    // تحديث حالة مهمة في قائمة التحقق
    async updateChecklistItem(id, is_completed) {
        const { data, error } = await zamClient
            .from('checklists')
            .update({ is_completed, completed_at: is_completed ? new Date().toISOString() : null })
            .eq('id', id)
            .select()
            .single();
        if (error) throw error;
        return data;
    },

    // إضافة تقرير يومي
    async addDailyReport(payload) {
        const { data, error } = await zamClient.from('daily_reports').insert([payload]).select().single();
        if (error) throw error;
        return data;
    },

    // جلب التقارير اليومية
    async getDailyReports(branchId = null) {
        let query = zamClient.from('daily_reports').select('*, branches(name), profiles(full_name)');
        if (branchId) query = query.eq('branch_id', branchId);
        const { data, error } = await query.order('created_at', { ascending: false });
        if (error) throw error;
        return data;
    }
};
